#pragma once

#include "CatchFakeit.hpp"

static fakeit::DefaultFakeit& Fakeit = fakeit::CatchFakeit::getInstance();
